import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-favour',
  templateUrl: './favour.component.html',
  styleUrls: ['./favour.component.css']
})
export class FavourComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
