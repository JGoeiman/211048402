# FavourRight

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 6.1.1.

# FOLLOW THESE INSTRUCTIONS 

## Create a Fresh Project
ng new favour-right

## Change directory into your project
cd favour-right

## Initialize git
git init

## Add the remote connection to this repository
git remote add origin https://github.com/sydwell2019/favour-right.git

## Download the respository
git fetch

## Set the head of the respository
git reset --hard origin/master

## Install the latest packages
npm install

## Load the project
ng serve
